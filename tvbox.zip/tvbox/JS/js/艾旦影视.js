var rule = Object.assign(muban.海螺3,{
title:'艾旦影视',
host:'https://www.lovedan.net',
url:'/vodshow/fyclass--------fypage---.html',
searchUrl:'/vodsearch/**----------fypage---.html',
cate_exclude: '福利图片|最新|排行',
});

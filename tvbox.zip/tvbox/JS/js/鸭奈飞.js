var rule = Object.assign(muban.mxpro,{
title:'鸭奈飞',
//host:'https://yanetflix.com',
host:'https://yanetflix.tv/',
url:'/vodshow/fyclass--------fypage---.html',
//class_parse:'.navbar-items&&li;a&&Text;a&&href;.*/(.*?).html',
class_name:'电视剧&电影&综艺&动漫',
class_url:'lianxuju&dianying&zongyi&dongman',
});

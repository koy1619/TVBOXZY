muban.海螺3.二级.desc = ';;;.hl-full-box .hl-col-xs-12:eq(3)&&Text;.hl-full-box .hl-col-xs-12:eq(4)&&Text';
muban.海螺3.二级.content = '.hl-col-xs-12.blurb&&Text';
var rule = {
    title:'小猫咪',
    模板:'海螺3',
    // host:'https://xmaomi.net',
    host:'https://xmaomi.top',
    url: '/vod___________show/fyclass--------fypage---.html',
}